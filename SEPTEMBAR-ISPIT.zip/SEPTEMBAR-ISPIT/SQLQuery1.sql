

--prije nego uneses graficki dizajner iskljuciti constraint min_lvl

insert into jobs
values ('graficki dizajner',8,250)

select * from jobs

alter table employee
add rad_staz int


update employee
set rad_staz = DATEDIFF(YEAR,hire_date,GETDATE())


select * from employee


alter table authors
add pozivni char(3)

update authors
set pozivni = CAST(LEFT(phone,3) AS INT)

select * from authors


select sales_id,ord_date,YEAR(sales.ord_date) AS god_nar,((MONTH(ord_date)-1)/3)+1 as kvartal,title_id into narudzba
from sales

select * from narudzba

alter table narudzba
add constraint PK_Sales_id primary key (sales_id)

alter table narudzba
add constraint FK_Title_id foreign key (title_id) references titles(title_id)







