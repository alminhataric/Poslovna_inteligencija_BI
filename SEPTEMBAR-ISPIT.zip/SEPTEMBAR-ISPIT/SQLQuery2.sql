

create database izdavac_DW

use izdavac_DW


create table dim_autor(
	autor_key int not null primary key (autor_key) identity (1,1),
	au_id varchar(11) not null,
	state char (2) null,
	contract bit not null,
	pozivni char (3) null,
	title_id varchar(6) not null
)


create table dim_narudzba(
	narudzba_key int not null primary key (narudzba_key) identity (1,1),
	sales_id int not null,
	ord_date datetime not null,
	god_nar int null,
	kvartal int null,
	title_id varchar(6) not null
)


create table dim_uposlenik(
	uposlenik_key int not null primary key (uposlenik_key) identity (1,1),
	emp_id char(9) not null,
	rad_staz int null,
	min_lvl tinyint not null,
	max_lvl tinyint not null,
	pub_id char(4) not null,
	title_id varchar(6) not null
)


create table fact_sales(
	sales_key int not null primary key (sales_key) identity (1,1),
	autor_key int not null constraint FK_Autor_key foreign key (autor_key) references dim_autor(autor_key),
	narudzba_key int not null constraint FK_Narudzba_key foreign key (narudzba_key) references dim_narudzba(narudzba_key),
	uposlenik_key int not null constraint FK_Uposlenik_key foreign key (uposlenik_key) references dim_uposlenik(uposlenik_key),
	sales_id int not null,
	title_id varchar(6) not null,
	qty smallint not null

)