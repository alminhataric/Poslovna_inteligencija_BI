

create database autobuski_prevoz_DW

use autobuski_prevoz_DW


create table dim_godina(
	godina_key int not null primary key (godina_key) identity(1,1),
	voznja_ID int not null,
	godina_voznje int null
)


create table dim_linija(
	linija_key int not null primary key (linija_key) identity(1,1),
	linija_ID int not null,
	vrijeme_polaska datetime null,
	vrijeme_dolaska datetime null,
	duzina_putovanja datetime null,
	linija_tip_naziv nvarchar(30) null
)


create table dim_radink(
	radnik_key int not null primary key (radnik_key) identity(1,1),
	radnik_ID varchar(5) not null,
	radnik_kval_opis nvarchar(20) null
)


create table dim_vozilo(
	vozilo_key int not null primary key (vozilo_key) identity(1,1),
	vozilo_ID int not null,
	vozilo_reg_oznaka nvarchar(10) null,
	vozilo_tip_naziv nvarchar(30) null,
	vozilo_max_br_sjed int null
)


create table fact_voznja(
	voznja_key int not null primary key (voznja_key) identity(1,1),
	godina_key int not null constraint FK_Godina_key foreign key (godina_key) references dim_godina(godina_key),
	linija_key int not null constraint FK_Linija_key foreign key (linija_key) references dim_linija(linija_key),
	radnik_key int not null constraint FK_Radnik_key foreign key (radnik_key) references dim_radink(radnik_key),
	vozilo_key int not null constraint FK_Vozilo_key foreign key (vozilo_key) references dim_vozilo(vozilo_key),
	voznja_prihod float null,
	zarada float null
)