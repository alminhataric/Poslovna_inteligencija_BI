

select voznja_ID,YEAR(dtm_voznje) as godina_voznje into god_voznje
from voznja

select * from god_voznje

alter table god_voznje
add constraint PK_Voznja_ID primary key (voznja_ID)


alter table god_voznje
add constraint FK_Voznja_ID foreign key (voznja_ID) references voznja(voznja_ID)

