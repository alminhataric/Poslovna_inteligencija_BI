

create database prodaja_DW

use prodaja_DW


create table dim_narudzba(
	narudzba_key int not null primary key(narudzba_key) identity(1,1),
	narudzbaID int not null,
	kupac_naziv  nvarchar(40) not null,
	kupac_grad nvarchar(15) null,
	kupac_drzava nvarchar(15) null,
	god_narudz int null,
	ispor_naziv nvarchar(40) not null,
	cijena_dostave money null
)



create table dim_popust(
	popust_key int not null primary key(popust_key) identity(1,1),
	popustID int not null,
	vr_popusta real null
)


create table dim_proizvod(
	proizvod_key int not null primary key(proizvod_key) identity(1,1),
	proizvodID int not null,
	kateg_naziv nvarchar(15) not null,
	proiz_naziv nvarchar(40) not null,
	dobav_naziv nvarchar(40) not null,
	dobav_grad nvarchar(15) null,
	dobav_drzava nvarchar(15) null
)


create table fact_nar_pr(
	nar_pr_key int not null primary key(nar_pr_key) identity(1,1),
	narudzba_key int not null constraint FK_Narudzba_key foreign key (narudzba_key) references dim_narudzba(narudzba_key),
	popust_key int not null constraint FK_Popust_key foreign key (popust_key) references dim_popust(popust_key),
	proizvod_key int not null constraint FK_Proizvod_key foreign key (proizvod_key) references dim_proizvod(proizvod_key),
	proiz_cijena money not null,
	kolicina smallint not null
)