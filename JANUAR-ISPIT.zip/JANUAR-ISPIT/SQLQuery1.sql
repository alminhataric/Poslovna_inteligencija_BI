


alter table narudzba 
add god_narudz int

update narudzba
set god_narudz = YEAR(dtm_narudzbe)

select * from narudzba