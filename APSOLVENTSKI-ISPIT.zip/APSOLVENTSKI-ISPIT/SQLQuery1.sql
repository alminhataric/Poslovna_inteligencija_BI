

alter table red_prihodi
add klasa_neto int 


update red_prihodi
set klasa_neto = 0
where neto < 499.99 or neto is null


update red_prihodi
set klasa_neto = 1
where neto between 500 and 999.99



update red_prihodi
set klasa_neto = 2
where  neto between 1000 and 1499.99


update red_prihodi
set klasa_neto = 3
where neto between 1500 and 1999.99

select * from red_prihodi



select red_prihodiID as red_prihodi_id,klasa_neto into red_pomocni
from red_prihodi

alter table red_pomocni
add constraint PK_red_prihod_id primary key (red_prihodi_id)


alter table red_pomocni
add constraint FK_red_prihod_id foreign key (red_prihodi_id) references red_prihodi(red_prihodiID)


alter table poslodavac
add domena varchar(3)


update poslodavac
set domena = SUBSTRING(web,CHARINDEX('.',web)+1,LEN(web))

select * from poslodavac