


create database prihodi_DW


use prihodi_DW


create table dim_klasa_neto(
	klasa_neto_key int not null primary key (klasa_neto_key) identity(1,1),
	red_prihodi_id int not null,
	klasa_neto int null
)

create table dim_osoba(
	osoba_key int not null primary key (osoba_key) identity(1,1),
	osoba_id int not null,
	naziv_grada varchar(50)null,
	naziv_drzave varchar(50) null,
	naziv_poslodavca varchar(50) null,
	domena_poslodavac varchar(3) null
)


create table dim_red_prihoda(
	red_prihoda_key int not null primary key (red_prihoda_key) identity(1,1),
	tip_red_prihodaID int not null,
	naziv_red_prihoda nvarchar(30) null
)

create table fact_red_prihodi(
	red_prihodi_key int not null primary key (red_prihodi_key) identity(1,1),
	klasa_neto_key int not null constraint FK_Klasa_neto_key foreign key (klasa_neto_key) references dim_klasa_neto(klasa_neto_key),
	osoba_key int not null constraint FK_Osoba_key foreign key (osoba_key) references dim_osoba(osoba_key),
	red_prihoda_key int not null constraint FK_Red_prihoda_key foreign key (red_prihoda_key) references dim_red_prihoda(red_prihoda_key),
	neto decimal(6,2) not null,
	zdravstveno int null,
	penzijsko int null
)


