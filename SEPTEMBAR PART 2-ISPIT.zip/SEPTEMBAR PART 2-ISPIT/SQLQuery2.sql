

create database tecajevi_DW

use tecajevi_DW


create table dim_polaznik_detalji (
	polaznik_detalji_key int not null primary key (polaznik_detalji_key) identity (1,1),
	Polaznik_ID int not null,
	Spol nvarchar(1) null,
	DatumRodjenja date null,
	UstanovaID int null,
	NazivGrada nvarchar(50) null,
	NazivZupanije nvarchar(50) null,
	NazivTipaPolaznika nvarchar(50) null

)


create table dim_ocjena (
	ocjena_key int not null primary key (ocjena_key) identity (1,1),
	PolaznikID int not null,
	OcjenaPohadjanja int null,
	NazivTecaja nvarchar(100) null,
	DatumPocetka date null,
	god_pocetka int null
)


create table dim_redovnost (
	redovnost_key int not null primary key (redovnost_key) identity (1,1),
	PolaznikID int not null,
	DatumPohadjanja date null,
	Prisutan int null
)

create table fact_polaznik(
	polaznik_key int not null primary key (polaznik_key) identity (1,1),
	polaznik_detalji_key int not null constraint FK_Polaznik_detalji_key foreign key (polaznik_detalji_key) references dim_polaznik_detalji(polaznik_detalji_key),
	ocjena_key int not null constraint FK_Ocjena_key foreign key (ocjena_key) references dim_ocjena(ocjena_key),
	redovnost_key int not null constraint FK_redovnost_key foreign key (redovnost_key) references dim_redovnost(redovnost_key),
	PolaznikID int not null

)
