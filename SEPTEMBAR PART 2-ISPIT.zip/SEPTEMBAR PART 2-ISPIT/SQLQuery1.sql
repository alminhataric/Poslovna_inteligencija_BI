

alter table odrzavanje
add god_pocetka int


update odrzavanje
set god_pocetka = YEAR(DatumPocetka)

select * from odrzavanje

alter table polaznik
add god_rodjenja int

update polaznik
set god_rodjenja = YEAR(DatumRodjenja)

select * from polaznik

select polaznik.PolaznikID,polaznik.Spol,polaznik.DatumRodjenja,polaznik.UstanovaID,grad.NazivGrada,zupanija.NazivZupanije,tip_polaznika.NazivTipaPolaznika  into polaznik_detalji
from polaznik,grad,zupanija,tip_polaznika
where polaznik.GradID = grad.GradID and grad.ZupanijaID = zupanija.ZupanijaID and polaznik.TipPolaznikaID = tip_polaznika.TipPolaznikaID

select * from polaznik_detalji

alter table polaznik_detalji
add constraint PK_Polaznik_ID primary key (PolaznikID)


alter table polaznik_detalji
add constraint FK_Polaznik_ID foreign key (PolaznikID) references polaznik(PolaznikID)