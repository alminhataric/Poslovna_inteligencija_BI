

create database bikes_DW

use bikes_DW

create table dim_products(
	products_key int not null primary key (products_key) identity (1,1),
	product_id int not null,
	product_name varchar(255) not null,
	brand_id int not null,
	category_id int not null,
	model_year smallint not null,
	list_price decimal (10,2) not null
)


create table dim_orders_customers(
	orders_customers_key int not null primary key (orders_customers_key) identity (1,1),
	order_id int not null,
	customer_id int null,
	order_date date not null,
	state varchar(25) null
)

create table dim_stores_orders(
	stores_orders_key int not null primary key (stores_orders_key) identity (1,1),
	order_id int not null,
	store_id int not null,
	store_name varchar(255) not null,
	city varchar(255) null
)



create table fact_items(
	fact_items_key int not null primary key (fact_items_key) identity (1,1),
	products_key int not null constraint FK_Products_key foreign key (products_key) references dim_products(products_key),
	orders_customers_key int not null constraint FK_Orders_customers_key foreign key (orders_customers_key) references dim_orders_customers(orders_customers_key),
	stores_orders_key int not null constraint FK_Stores_orders_key foreign key (stores_orders_key) references dim_stores_orders(stores_orders_key),
	quantity int not null,
	list_price decimal (10,2) not null,
	discount decimal (4,2) not null

)