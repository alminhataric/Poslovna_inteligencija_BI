


select (CAST(sales.orders.order_id as varchar(5)) + ' - ' + CAST(item_id as varchar(15))) as kljuc_id,sales.orders.order_id ,item_id,production.products.product_id,quantity,order_items.list_price,discount into items
from sales.order_items,production.products,sales.orders
where order_items.product_id = production.products.product_id and order_items.order_id = sales.orders.order_id

select * from items



